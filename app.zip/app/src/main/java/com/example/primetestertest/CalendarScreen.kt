package com.example.primetestertest

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.collectLatest
import java.time.LocalDate
import java.time.YearMonth
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope


@Composable
fun CalendarScreen(
    context: Context,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        var selectedAgeInDays by remember { mutableStateOf<Int?>(null) }
        val birthdayFlow = remember { loadBirthday(context) }
        var birthday by remember { mutableStateOf<LocalDate?>(null) }
        val scope = rememberCoroutineScope()

        // Flow → State
        LaunchedEffect(Unit) {
            birthdayFlow.collectLatest { birthday = it }
        }

        var currentMonth by remember { mutableStateOf(YearMonth.now()) }
        var showDatePicker by remember { mutableStateOf(false) }

        selectedAgeInDays?.let { days ->
            Text(
                text = "Alter an diesem Tag: $days Tage",
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(top = 16.dp)
            )
        }


        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // Monat Navigation
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(onClick = { currentMonth = currentMonth.minusMonths(1) }) {
                    Text("<")
                }
                Text(
                    "${currentMonth.month} ${currentMonth.year}",
                    style = MaterialTheme.typography.headlineSmall
                )
                Button(onClick = { currentMonth = currentMonth.plusMonths(1) }) {
                    Text(">")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (birthday != null) {
                CalendarGrid(
                    month = currentMonth,
                    birthday = birthday!!,
                    onDayClick = { date, days ->
                        selectedAgeInDays = days
                    }
                )
            } else {
                Text("Bitte ein Geburtsdatum eingeben")
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Geburtstag + Ändern Button
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Geburtsdatum: ${birthday ?: "Nicht gesetzt"}")

                Spacer(modifier = Modifier.height(8.dp))

                Button(onClick = { showDatePicker = true }) {
                    Text("Ändern")
                }
            }

            if (showDatePicker) {
                DatePickerDialog(
                    onDismissRequest = { showDatePicker = false },
                    onDateSelected = { newDate ->
                        showDatePicker = false
                        scope.launch {
                            saveBirthday(context, newDate)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun CalendarGrid(
    month: YearMonth,
    birthday: LocalDate,
    onDayClick: (LocalDate, Int) -> Unit = { _, _ -> }
) {
    val firstDay = month.atDay(1)
    val daysInMonth = month.lengthOfMonth()
    val firstDayOfWeek = (firstDay.dayOfWeek.value + 6) % 7   // Montag = 0

    Column {

        // Wochentage
        Row(modifier = Modifier.fillMaxWidth()) {
            listOf("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So").forEach {
                Text(
                    text = it,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        val totalCells = firstDayOfWeek + daysInMonth
        val rows = (totalCells + 6) / 7

        var dayCounter = 1

        Column {
            repeat(rows) { row ->
                Row(modifier = Modifier.fillMaxWidth()) {
                    repeat(7) { col ->
                        val index = row * 7 + col

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .padding(4.dp),
                            contentAlignment = Alignment.Center
                        ) {

                            if (index >= firstDayOfWeek && dayCounter <= daysInMonth) {

                                val date = month.atDay(dayCounter)

                                // 👉 Hier holen wir die Tage seit Geburtstag
                                val days = getDays(date, birthday)

                                // 👉 Primzahl-Markierung
                                val isPrime = isPrime(days)

                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clickable {
                                            // 👉 Beim Klick geben wir die Tage zurück
                                            onDayClick(date, days)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {

                                    if (isPrime) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .background(
                                                    Color(0xFF4A90E2),
                                                    shape = CircleShape
                                                )
                                        )
                                    }

                                    Text(
                                        text = dayCounter.toString(),
                                        color = Color.White
                                    )
                                }

                                dayCounter++
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DatePickerDialog(
    onDismissRequest: () -> Unit,
    onDateSelected: (LocalDate) -> Unit
) {
    var year by remember { mutableStateOf(2000) }
    var month by remember { mutableStateOf(1) }
    var day by remember { mutableStateOf(1) }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        title = { Text("Geburtsdatum wählen") },
        text = {
            Column {
                OutlinedTextField(
                    value = year.toString(),
                    onValueChange = { year = it.toIntOrNull() ?: year },
                    label = { Text("Jahr") }
                )
                OutlinedTextField(
                    value = month.toString(),
                    onValueChange = { month = it.toIntOrNull() ?: month },
                    label = { Text("Monat") }
                )
                OutlinedTextField(
                    value = day.toString(),
                    onValueChange = { day = it.toIntOrNull() ?: day },
                    label = { Text("Tag") }
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                onDateSelected(LocalDate.of(year, month, day))
            }) {
                Text("OK")
            }
        },
        dismissButton = {
            Button(onClick = onDismissRequest) {
                Text("Abbrechen")
            }
        }
    )
}