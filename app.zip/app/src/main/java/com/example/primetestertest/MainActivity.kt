package com.example.primetestertest

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteScaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.PreviewScreenSizes
import com.example.primetestertest.ui.theme.PrimeTesterTestTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PrimeTesterTestTheme {
                PrimeTesterTestApp()
            }
        }
    }
}

@PreviewScreenSizes
@Composable
fun PrimeTesterTestApp() {
    NavigationSuiteScaffold(
        navigationSuiteItems = {
            AppDestinations.entries.filter { it.showInBottomBar }.forEach {
                item(
                    icon = { Icon(it.icon, contentDescription = it.label) },
                    label = { Text(it.label) },
                    selected = it == AppNavigation.currentDestination,
                    onClick = { AppNavigation.currentDestination = it }
                )
            }
        }
    ) {
        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
            when (AppNavigation.currentDestination) {
                AppDestinations.HOME -> PrimeCheckerScreen(
                    modifier = Modifier.padding(innerPadding)
                )
                AppDestinations.PRIME_DAYS -> PrimeDaysScreen(
                    modifier = Modifier.padding(innerPadding)
                )
                AppDestinations.FEATURES -> FeaturesScreen(
                    modifier = Modifier.padding(innerPadding)
                )
                AppDestinations.DIAGRAMM -> DiagrammScreen(
                    modifier = Modifier.padding(innerPadding)
                )
                AppDestinations.FACTORISATION -> FactorisationScreen(
                    context = LocalContext.current,
                    modifier = Modifier.padding(innerPadding)
                )
                AppDestinations.CALENDAR -> CalendarScreen(
                    context = LocalContext.current,
                    modifier = Modifier.padding(innerPadding)
                )
                AppDestinations.QUIZ -> QuizScreen(
                    context = LocalContext.current,
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }
}

enum class AppDestinations(
    val label: String,
    val icon: ImageVector,
    val showInBottomBar: Boolean
) {
    HOME("Home", Icons.Default.Home, true),
    CALENDAR("Kalender", Icons.Default.Star, true),
    FEATURES("Weiteres", Icons.Default.AccountBox, true),
    DIAGRAMM("Diagramm", Icons.Default.Star, false),
    FACTORISATION("Primfaktoren", Icons.Default.Star, false),

    PRIME_DAYS("Primzahltage", Icons.Default.Favorite, false),
    QUIZ("Quiz", Icons.Default.Star, false),
}
