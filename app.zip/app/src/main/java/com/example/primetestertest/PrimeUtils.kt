package com.example.primetestertest

import java.time.LocalDate
import java.time.temporal.ChronoUnit

import kotlin.math.sqrt

fun isPrime(n: Int): Boolean {
    if (n < 2) return false
    if (n == 2) return true
    if (n % 2 == 0) return false

    val limit = sqrt(n.toDouble()).toInt()
    for (i in 3..limit step 2) {
        if (n % i == 0) return false
    }
    return true
}

fun isPalindrome(n: Int): Boolean {
    val s = n.toString()
    return s == s.reversed()
}

fun generatePrimesInRange(start: Int, end: Int): List<Int> {
    return (start..end).filter { isPrime(it) }
}

fun isPrimeDay(date: LocalDate, birthday: LocalDate): Boolean {
    val days = ChronoUnit.DAYS.between(birthday, date).toInt()
    return isPrime(days)
}

fun getDays(date: LocalDate, birthday: LocalDate): Int {
    return ChronoUnit.DAYS.between(birthday,date).toInt()
}

fun primeFactors(n: Int): List<Int> {
    var num = n
    val factors = mutableListOf<Int>()

    var divisor = 2
    while (divisor * divisor <= num) {
        while (num % divisor == 0) {
            factors.add(divisor)
            num /= divisor
        }
        divisor++
    }
    if (num > 1) factors.add(num)

    return factors
}


