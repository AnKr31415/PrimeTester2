package com.example.primetestertest

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import java.time.LocalDate

val Context.dataStore by preferencesDataStore(name = "user_prefs")

object UserPreferences {
    val BIRTHDAY = stringPreferencesKey("birthday")
}

suspend fun saveBirthday(context: Context, date: LocalDate) {
    context.dataStore.edit { prefs ->
        prefs[UserPreferences.BIRTHDAY] = date.toString()
    }
}

fun loadBirthday(context: Context) =
    context.dataStore.data.map { prefs ->
        prefs[UserPreferences.BIRTHDAY]?.let { LocalDate.parse(it) }
    }