package com.example.primetestertest

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp



@Composable
fun PrimeCheckerScreen(modifier: Modifier = Modifier) {

    var input by rememberSaveable { mutableStateOf("") }
    var result by rememberSaveable { mutableStateOf("") }

    var rangeStart by rememberSaveable { mutableStateOf("") }
    var rangeEnd by rememberSaveable { mutableStateOf("") }

    // Liste der Primzahlen
    var primesList by rememberSaveable { mutableStateOf(listOf<Int>()) }

    Column(modifier = modifier.padding(16.dp)) {

        // Einzelne Zahl prüfen
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text("Zahl eingeben") }
        )

        Button(
            onClick = {
                val number = input.toIntOrNull()
                result = if (number == null) {
                    "Bitte eine gültige Zahl eingeben"
                } else if (isPrime(number)) {
                    "$number ist eine Primzahl"
                } else {
                    "$number ist keine Primzahl"
                }
            },
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Text("Prüfen")
        }

        Text(
            text = result,
            modifier = Modifier.padding(top = 16.dp)
        )

        // Bereichsberechnung
        OutlinedTextField(
            value = rangeStart,
            onValueChange = { rangeStart = it },
            label = { Text("Von") },
            modifier = Modifier.padding(top = 32.dp)
        )

        OutlinedTextField(
            value = rangeEnd,
            onValueChange = { rangeEnd = it },
            label = { Text("Bis") },
            modifier = Modifier.padding(top = 8.dp)
        )

        Row(modifier = Modifier.padding(top = 16.dp)) {

            Button(
                onClick = {
                    val start = rangeStart.toIntOrNull()
                    val end = rangeEnd.toIntOrNull()

                    primesList =
                        if (start == null || end == null || start > end) {
                            emptyList()
                        } else {
                            (start..end).filter { isPrime(it) }
                        }
                }
            ) {
                Text("Bereich prüfen")
            }

            Spacer(modifier = Modifier.padding(8.dp))

            Button(
                onClick = {
                    val start = rangeStart.toIntOrNull()
                    val end = rangeEnd.toIntOrNull()

                    primesList =
                        if (start == null || end == null || start > end) {
                            emptyList()
                        } else {
                            (start..end)
                                .filter { isPrime(it) }
                                .filter { isPalindrome(it) }
                        }
                }
            ) {
                Text("Palindrome")
            }
        }

        val scrollState = rememberScrollState()

        Column(
            modifier = Modifier
                .padding(top = 16.dp)
                .verticalScroll(scrollState)
        ) {
            Text(
                text = primesList.joinToString(", "),
                modifier = Modifier.padding(4.dp)
            )
        }
    }
}

